# client.py

import socket
import argparse
import json
import base64
import os
import sys

# Constants
MSS = 1400  # Maximum Segment Size in bytes
BUFFER_SIZE = 4096  # Socket buffer size

def parse_packet(packet):
    """
    Parse the received JSON packet.
    """
    try:
        packet_dict = json.loads(packet.decode())
        if 'end' in packet_dict and packet_dict['end'] is True:
            return 'END', None
        seq_num = packet_dict['seq_num']
        data_length = packet_dict['data_length']
        data = base64.b64decode(packet_dict['data'].encode())
        return seq_num, data
    except json.JSONDecodeError:
        print("Received malformed packet.")
        return None, None

def create_ack_packet(ack_num):
    """
    Create a JSON-formatted ACK packet.
    """
    ack_dict = {
        "ack_num": ack_num
    }
    return json.dumps(ack_dict).encode()

def receive_file(server_ip, server_port, output_file_path):
    """
    Receive the file from the server with reliability, handling packet loss
    and reordering.
    """
    # Initialize UDP socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.settimeout(2)  # Initial timeout for server response

    server_address = (server_ip, server_port)
    expected_seq_num = 0
    buffer = {}  # Buffer for out-of-order packets

    # Send initial connection request to server
    connection_established = False
    while not connection_established:
        try:
            print("Sending connection request to server...")
            client_socket.sendto(b"START", server_address)
            data, _ = client_socket.recvfrom(BUFFER_SIZE)
            packet_type, _ = parse_packet(data)
            if packet_type == 'END':
                print("Server sent an immediate end signal. No file to receive.")
                client_socket.close()
                return
            else:
                # Assuming the server responds with the first data packet
                print("Connection established with server.")
                connection_established = True
        except socket.timeout:
            print("No response from server, retrying connection request...")

    # Open the output file in binary write mode
    with open(output_file_path, 'wb') as file:
        while True:
            try:
                # Receive the packet
                packet, _ = client_socket.recvfrom(MSS + 1000)  # Allow room for headers

                # Parse the packet
                seq_num, data = parse_packet(packet)

                if seq_num == 'END':
                    print("Received END signal from server, file transfer complete.")
                    break

                if seq_num is None:
                    # Malformed packet, ignore
                    continue

                if seq_num == expected_seq_num:
                    # In-order packet
                    file.write(data)
                    expected_seq_num += 1
                    print(f"Received packet {seq_num}, writing to file.")

                    # Check buffer for any subsequent packets
                    while expected_seq_num in buffer:
                        buffered_data = buffer.pop(expected_seq_num)
                        file.write(buffered_data)
                        print(f"Writing buffered packet {expected_seq_num} to file.")
                        expected_seq_num += 1

                    # Send cumulative ACK
                    ack_packet = create_ack_packet(expected_seq_num - 1)
                    client_socket.sendto(ack_packet, server_address)
                    print(f"Sent cumulative ACK for packet {expected_seq_num - 1}.")

                elif seq_num > expected_seq_num:
                    # Out-of-order packet, buffer it
                    if seq_num not in buffer:
                        buffer[seq_num] = data
                        print(f"Buffered out-of-order packet {seq_num}.")

                    # Send cumulative ACK for the last in-order packet
                    ack_packet = create_ack_packet(expected_seq_num - 1)
                    client_socket.sendto(ack_packet, server_address)
                    print(f"Sent cumulative ACK for packet {expected_seq_num - 1} (duplicate ACK).")

                else:
                    # Duplicate packet, resend ACK
                    ack_packet = create_ack_packet(expected_seq_num - 1)
                    client_socket.sendto(ack_packet, server_address)
                    print(f"Received duplicate packet {seq_num}, resent ACK for {expected_seq_num - 1}.")

            except socket.timeout:
                # No data received within timeout, resend the last ACK to prompt retransmission
                print("Timeout waiting for data. Resending last ACK.")
                ack_packet = create_ack_packet(expected_seq_num - 1)
                client_socket.sendto(ack_packet, server_address)

    # Close the socket after transfer is complete
    client_socket.close()
    print(f"File received successfully and saved as '{output_file_path}'.")

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Reliable file receiver over UDP.')
    parser.add_argument('server_ip', help='IP address of the server')
    parser.add_argument('server_port', type=int, help='Port number of the server')
    parser.add_argument('-o', '--output', default='received_file.txt', help='Output file path')

    args = parser.parse_args()

    # Check if output file already exists to prevent overwriting
    if os.path.exists(args.output):
        print(f"Error: Output file '{args.output}' already exists. Please choose a different file name.")
        sys.exit(1)

    # Run the client
    receive_file(args.server_ip, args.server_port, args.output)

if __name__ == "__main__":
    main()
    