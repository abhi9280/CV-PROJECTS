# server.py

import socket
import time
import argparse
import json
import base64
import threading
import os
import sys

# Constants
MSS = 1400  # Maximum Segment Size in bytes
DUP_ACK_THRESHOLD = 3  # Threshold for duplicate ACKs to trigger fast recovery
INITIAL_TIMEOUT = 1.0  # Initial timeout in seconds
WINDOW_SIZE = 5  # Number of packets in flight

def create_packet(seq_num, data):
    """
    Create a JSON-formatted data packet with sequence number and data.
    """
    packet_dict = {
        "seq_num": seq_num,
        "data_length": len(data),
        "data": base64.b64encode(data).decode()  # Encode binary data to base64 string
    }
    return json.dumps(packet_dict).encode()

def parse_ack_packet(ack_packet):
    """
    Parse the received ACK packet to extract the acknowledgment number.
    """
    try:
        ack_dict = json.loads(ack_packet.decode())
        ack_num = ack_dict['ack_num']
        return ack_num
    except (json.JSONDecodeError, KeyError):
        print("Received malformed ACK packet.")
        return None

def send_end_signal(server_socket, client_address):
    """
    Send an end-of-file signal to the client.
    """
    end_packet = json.dumps({"end": True}).encode()
    server_socket.sendto(end_packet, client_address)
    print("Sent END signal to client.")

def retransmit_packet(server_socket, client_address, packet):
    """
    Retransmit a single packet to the client.
    """
    server_socket.sendto(packet, client_address)
    print("Retransmitted a packet.")

def send_file(server_ip, server_port, file_path, enable_fast_recovery):
    """
    Send a predefined file to the client, ensuring reliability over UDP.
    """
    # Initialize UDP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((server_ip, server_port))
    print(f"Server listening on {server_ip}:{server_port}")

    client_address = None

    # Wait for client to initiate connection
    print("Waiting for client connection...")
    while True:
        try:
            data, addr = server_socket.recvfrom(1024)
            if data == b"START":
                client_address = addr
                print(f"Connection established with client {client_address}")
                break
            else:
                print(f"Received unexpected data from {addr}. Ignoring.")
        except KeyboardInterrupt:
            print("\nServer shutting down.")
            server_socket.close()
            sys.exit(0)

    # Open the file for reading
    try:
        file = open(file_path, 'rb')
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        server_socket.close()
        sys.exit(1)

    # Initialize variables
    seq_num = 0
    window_base = 0
    unacked_packets = {}  # seq_num: (packet_data, send_time)
    duplicate_ack_count = {}  # ack_num: count
    last_ack_received = -1
    timeout = INITIAL_TIMEOUT

    # Function to send packets within the window
    def send_packets():
        nonlocal seq_num, window_base
        while len(unacked_packets) < WINDOW_SIZE:
            chunk = file.read(MSS)
            if not chunk:
                break  # No more data to send

            packet = create_packet(seq_num, chunk)
            server_socket.sendto(packet, client_address)
            send_time = time.time()
            unacked_packets[seq_num] = (packet, send_time)
            print(f"Sent packet {seq_num}")
            seq_num += 1

    # Initial sending of packets
    send_packets()

    # Start the main loop to handle ACKs and retransmissions
    while True:
        try:
            server_socket.settimeout(timeout)
            ack_packet, _ = server_socket.recvfrom(1024)
            ack_num = parse_ack_packet(ack_packet)

            if ack_num is None:
                continue  # Malformed ACK, ignore

            print(f"Received ACK for packet {ack_num}")

            if ack_num > last_ack_received:
                # New ACK received
                last_ack_received = ack_num
                # Remove acknowledged packets from unacked_packets
                keys_to_remove = [seq for seq in unacked_packets if seq <= ack_num]
                for key in keys_to_remove:
                    del unacked_packets[key]
                # Reset duplicate ACK count
                duplicate_ack_count = {}
                # Send new packets if available
                send_packets()
            else:
                # Duplicate ACK received
                if ack_num in duplicate_ack_count:
                    duplicate_ack_count[ack_num] += 1
                else:
                    duplicate_ack_count[ack_num] = 1
                print(f"Duplicate ACK count for {ack_num}: {duplicate_ack_count[ack_num]}")

                if enable_fast_recovery and duplicate_ack_count[ack_num] == DUP_ACK_THRESHOLD:
                    print("Duplicate ACK threshold reached. Initiating fast recovery.")
                    if ack_num in unacked_packets:
                        packet_to_retransmit, _ = unacked_packets[ack_num]
                        server_socket.sendto(packet_to_retransmit, client_address)
                        print(f"Fast retransmitted packet {ack_num}")

            # Update timeout based on RTT estimation (optional for simplicity)
            # This implementation uses a fixed timeout value

        except socket.timeout:
            print("Timeout occurred. Retransmitting unacknowledged packets.")
            # Retransmit all unacknowledged packets
            for seq, (packet, _) in unacked_packets.items():
                server_socket.sendto(packet, client_address)
                print(f"Retransmitted packet {seq}")
            # Optionally, double the timeout for exponential backoff
            timeout = min(timeout * 2, 60)  # Cap the timeout to 60 seconds
            print(f"Updated timeout to {timeout} seconds.")

        # Check if all data has been sent and acknowledged
        if len(unacked_packets) == 0:
            # Check if end of file has been reached
            current_pos = file.tell()
            file.seek(0, os.SEEK_END)
            end_pos = file.tell()
            file.seek(current_pos, os.SEEK_SET)
            if current_pos >= end_pos:
                # All data has been sent and acknowledged
                send_end_signal(server_socket, client_address)
                break

    # Close the file and socket
    file.close()
    server_socket.close()
    print("File transfer complete. Server shutting down.")

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Reliable file transfer server over UDP.')
    parser.add_argument('server_ip', help='IP address of the server')
    parser.add_argument('server_port', type=int, help='Port number of the server')
    parser.add_argument('file_path', help='Path to the file to be sent')
    parser.add_argument('--fast_recovery', action='store_true', help='Enable fast recovery on duplicate ACKs')

    args = parser.parse_args()

    # Check if file exists
    if not os.path.isfile(args.file_path):
        print(f"Error: File '{args.file_path}' does not exist.")
        sys.exit(1)

    # Run the server
    send_file(args.server_ip, args.server_port, args.file_path, args.fast_recovery)

if __name__ == "__main__":
    main()
