#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <thread>
#include <netinet/in.h>
#include <unistd.h>
#include <nlohmann/json.hpp>  // JSON handling

using json = nlohmann::json;

const int BUFFER_SIZE = 1024;

// Function to handle a client connection
void handleClient(int client_sock, const std::vector<std::string>& words, int p) {
    int offset;
    char buffer[BUFFER_SIZE];

    while (true) {
        // Read offset from client
        ssize_t bytes_read = read(client_sock, buffer, BUFFER_SIZE);
        if (bytes_read <= 0) {
            std::cerr << "Client disconnected." << std::endl;
            break;
        }
        buffer[bytes_read] = '\0';
        sscanf(buffer, "%d\n", &offset);

        if (offset >= words.size()) {
            std::string end_msg = "$$\n";
            send(client_sock, end_msg.c_str(), end_msg.length(), 0);
        } else {
            std::string response;
            for (int i = 0; i < p && offset + i < words.size(); i++) {
                response += words[offset + i] + ",";
            }
            if (offset + p >= words.size()) {
                response += "EOF";
            }
            response += "\n";
            send(client_sock, response.c_str(), response.length(), 0);
        }
    }
    close(client_sock);
}

int main() {
    // Read config.json
    std::ifstream config_file("config.json");
    json config;
    config_file >> config;

    int port = config["server_port"];
    int p = config["p"];
    std::string filename = config["filename"];

    // Read words from file
    std::ifstream infile(filename);
    std::string word;
    std::vector<std::string> words;
    while (std::getline(infile, word, ',')) {
        words.push_back(word);
    }

    // Create socket
    int server_sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    // Bind socket
    bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    listen(server_sock, 5);
    std::cout << "Server listening on port " << port << std::endl;

    // Handle incoming client connections in separate threads
    while (true) {
        struct sockaddr_in client_addr;
        socklen_t client_addr_len = sizeof(client_addr);
        int client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_addr_len);

        std::thread(handleClient, client_sock, std::ref(words), p).detach();
    }

    close(server_sock);
    return 0;
}
