#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <thread>
#include <arpa/inet.h>
#include <unistd.h>
#include <nlohmann/json.hpp>  // JSON handling

using json = nlohmann::json;

const int BUFFER_SIZE = 1024;

// Function to handle a single client thread
void clientTask(int id, const std::string& server_ip, int server_port, int num_words) {
    // Create socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    inet_pton(AF_INET, server_ip.c_str(), &server_addr.sin_addr);

    connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr));

    // Request words from server
    int offset = id * num_words;
    std::string request = std::to_string(offset) + "\n";
    send(sock, request.c_str(), request.length(), 0);

    std::map<std::string, int> word_count;
    char buffer[BUFFER_SIZE];
    while (true) {
        ssize_t bytes_received = recv(sock, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) break;

        buffer[bytes_received] = '\0';
        std::string data(buffer);
        
        if (data == "$$\n") {
            break;  // No more words available
        } else {
            size_t pos = 0;
            std::string word;
            while ((pos = data.find(',')) != std::string::npos) {
                word = data.substr(0, pos);
                if (word == "EOF") {
                    close(sock);
                    goto output_file;
                }
                word_count[word]++;
                data.erase(0, pos + 1);
            }
        }
    }

output_file:
    // Output to file
    std::string output_filename = "output_" + std::to_string(id) + ".txt";
    std::ofstream outfile(output_filename);
    for (const auto& wc : word_count) {
        outfile << wc.first << "," << wc.second << std::endl;
    }
    outfile.close();
    close(sock);
}

int main() {
    // Read config.json
    std::ifstream config_file("config.json");
    json config;
    config_file >> config;

    std::string server_ip = config["server_ip"];
    int server_port = config["server_port"];
    int num_clients = config["n"];
    int num_words = config["k"];

    // Create threads for clients
    std::vector<std::thread> clients;
    for (int i = 0; i < num_clients; i++) {
        clients.push_back(std::thread(clientTask, i, server_ip, server_port, num_words));
    }

    for (auto& client : clients) {
        client.join();
    }

    return 0;
}
