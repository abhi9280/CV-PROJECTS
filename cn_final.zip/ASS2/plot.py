import matplotlib.pyplot as plt
import numpy as np

# Reading times.txt for the completion times
times = []
with open('times.txt', 'r') as f:
    for line in f:
        if line.strip():
            parts = line.strip().split(', ')
            if len(parts) == 2:
                time = float(parts[1].split(': ')[1].split()[0])
                times.append(time)

# We have 10 runs for each p value from 1 to 10
p_values = np.arange(1, 11)
average_times = np.array([np.mean(times[i*10:(i+1)*10]) for i in range(10)])
std_dev = np.array([np.std(times[i*10:(i+1)*10]) for i in range(10)])

# Plotting the graph
plt.errorbar(p_values, average_times, yerr=std_dev, fmt='-o', ecolor='r', capsize=5)
plt.xlabel('p (Words per Packet)')
plt.ylabel('Completion Time (ms)')
plt.title('Completion Time vs. Number of Words per Packet')
plt.grid(True)
plt.savefig('plot.png')
plt.show()
