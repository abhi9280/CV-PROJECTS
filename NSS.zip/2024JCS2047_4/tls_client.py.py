#!/usr/bin/env python3

import socket, ssl, sys, pprint, os

DEFAULT_PORT = 443
DEFAULT_CADIR = "/etc/ssl/certs"
USE_IMAGE = False
CHECK_HOSTNAME = True

if len(sys.argv) < 2:
    print("Usage: python3 tls_client.py <hostname>")
    sys.exit(1)

hostname = sys.argv[1]
cadir = "./certs" if os.path.exists("./certs") else DEFAULT_CADIR

context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
context.load_verify_locations(capath=cadir)
context.verify_mode = ssl.CERT_REQUIRED
context.check_hostname = CHECK_HOSTNAME

sock = socket.create_connection((hostname, DEFAULT_PORT))
input("TCP connection established. Press Enter to start TLS handshake...")

ssock = context.wrap_socket(sock, server_hostname=hostname, do_handshake_on_connect=False)
try:
    ssock.do_handshake()
except ssl.SSLError as e:
    print(f"TLS Handshake failed: {e}")
    ssock.close()
    sys.exit(1)

print("\nCipher used:", ssock.cipher())
print("\nServer certificate:")
pprint.pprint(ssock.getpeercert())

input("\nTLS handshake complete. Press Enter to send HTTP request...")

print("\nBeginning Task 4: Data Communication")

if USE_IMAGE:
    request_path = "/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/640px-Google_2015_logo.svg.png"
    http_version = "HTTP/1.1"
    connection_header = "Connection: close"
else:
    request_path = "/"
    http_version = "HTTP/1.0"
    connection_header = ""

request = (
    f"GET {request_path} {http_version}\r\n"
    f"Host: {hostname}\r\n"
    f"{connection_header}\r\n\r\n"
).encode('utf-8')

print("\nSending HTTP request:")
print(request.decode('utf-8', errors='replace'))

ssock.sendall(request)

print("\nReceiving HTTP response...")
response = b""
while True:
    chunk = ssock.recv(2048)
    if not chunk:
        break
    response += chunk

if USE_IMAGE:
    header_end = response.find(b"\r\n\r\n") + 4
    headers = response[:header_end]
    image_data = response[header_end:]
    print("\nHTTP Response Headers:")
    print(headers.decode('utf-8', errors='replace'))

    with open("downloaded_image.png", "wb") as f:
        f.write(image_data)
    print("\nImage saved as 'downloaded_image.png'")
else:
    print("\nHTTP Response:")
    for line in response.split(b"\r\n"):
        print(line.decode('utf-8', errors='replace'))

input("\nData communication complete. Press Enter to close connection...")

try:
    ssock.shutdown(socket.SHUT_RDWR)
except OSError:
    pass
finally:
    ssock.close()
