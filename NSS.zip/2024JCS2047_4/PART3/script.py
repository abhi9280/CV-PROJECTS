import pandas as pd
import numpy as np
import contextlib

# ----------------------------------------------------------------------
# Loads a single CSV file into a DataFrame and performs cleaning and feature engineering:
# 1. Reads all columns, forcing numeric columns to numeric (coercing errors to 0).
# 2. Parses start/stop timestamps, drops any rows missing key fields.
# 3. Computes per‑flow packet counts, filters out flows with zero packets.
# 4. Computes total bytes and average packet size per flow.
#
# Args:
#     csv_file (str): Path to the CSV file containing network flow logs.
# Returns:
#     pd.DataFrame: Cleaned and augmented DataFrame ready for analysis.
# ----------------------------------------------------------------------
def load_and_prepare_data(csv_file):
    df = pd.read_csv(csv_file, low_memory=False)

    # Ensure byte/packet counts are numeric, fill parsing errors with 0
    for col in [
        "totalSourceBytes", "totalDestinationBytes",
        "totalSourcePackets", "totalDestinationPackets"
    ]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Parse timestamps, drop rows where parsing failed or IPs are missing
    df["startDateTime"] = pd.to_datetime(df["startDateTime"], errors="coerce")
    df["stopDateTime"]  = pd.to_datetime(df["stopDateTime"],  errors="coerce")
    df = df.dropna(subset=["startDateTime", "stopDateTime", "source", "destination"])

    # Compute total packets per flow and remove flows with zero packets
    df["packets_sum"] = df.totalSourcePackets + df.totalDestinationPackets
    df = df[df.packets_sum > 0]

    # Compute total bytes and average packet size per flow
    df["bytes_sum"] = df.totalSourceBytes + df.totalDestinationBytes
    df["avg_pkt_size_per_flow"] = df.bytes_sum / df.packets_sum
    df["total_bytes"] = df.bytes_sum

    return df

# ----------------------------------------------------------------------
# Performs statistical anomaly detection on traffic:
# - Calculates mean/std thresholds for packet size, hourly and daily flow counts.
# - Flags hours/days where flow counts exceed mean + 2*std.
# - Detects days with large shifts in protocol distribution.
# - Identifies IPs with unusually high or low total bytes.
#
# Args:
#     df (pd.DataFrame): Prepared DataFrame from load_and_prepare_data.
# ----------------------------------------------------------------------
def statistical_traffic_analysis(df):
    print("\n==Statistical Traffic Analysis==")

    # Packet‑size anomalies
    pk = df.avg_pkt_size_per_flow
    pkt_mean, pkt_std = pk.mean(), pk.std()
    pkt_thresh = pkt_mean + 2 * pkt_std
    print(f"Packet size: mean={pkt_mean:.1f}, std={pkt_std:.1f}, threshold={pkt_thresh:.1f}")

    # Hourly flow count anomalies
    df["hour"] = df.startDateTime.dt.floor("h")
    fph = df.groupby("hour").size()
    hp_mean, hp_std = fph.mean(), fph.std()
    hp_thresh = hp_mean + 2 * hp_std
    print(f"Hourly flows: mean={hp_mean:.1f}, std={hp_std:.1f}, threshold={hp_thresh:.1f}")
    spikes = fph[fph > hp_thresh]
    if not spikes.empty:
        print("  Anomalous hours:\n", spikes)

    # Daily flow count anomalies
    df["day"] = df.startDateTime.dt.floor("D")
    fpd = df.groupby("day").size()
    dp_mean, dp_std = fpd.mean(), fpd.std()
    dp_thresh = dp_mean + 2 * dp_std
    print(f"Daily flows: mean={dp_mean:.1f}, std={dp_std:.1f}, threshold={dp_thresh:.1f}")
    d_spikes = fpd[fpd > dp_thresh]
    if not d_spikes.empty:
        print("  Anomalous days:\n", d_spikes)

    # Protocol distribution change detection
    pdist = (
        df.groupby("day")["protocolName"]
          .value_counts(normalize=True)
          .unstack()
          .fillna(0)
    )
    pchg = pdist.diff().abs().max(axis=1)
    prot_mean, prot_std = pchg.mean(), pchg.std()
    prot_thresh = prot_mean + 2 * prot_std
    print(f"Protocol‑change threshold: {prot_thresh:.2f}")
    for day, change in pchg.items():
        if change > prot_thresh:
            print(f"  {day.date()}: max change={change:.2f}")

    # Outlier IPs by total bytes transferred
    ip_tot = df.groupby("source").total_bytes.sum()
    ip_mean, ip_std = ip_tot.mean(), ip_tot.std()
    hi = ip_tot[ip_tot > ip_mean + 2 * ip_std]
    lo = ip_tot[ip_tot < ip_mean - 2 * ip_std]
    print("High‑volume IPs:", hi.index.tolist() or "None")
    print("Low‑volume  IPs:", lo.index.tolist() or "None")

# ----------------------------------------------------------------------
# Detects behavioral anomalies:
# - Finds IPs with a sudden traffic spike after ≥3 inactive hours.
# - Identifies coordinated attacks: many sources to the same destination within one hour.
# - Flags destinations receiving unusually diverse sources overall.
#
# Args:
#     df (pd.DataFrame): Prepared DataFrame from load_and_prepare_data.
# ----------------------------------------------------------------------
def behavioral_analysis(df):
    print("\n==Behavioral Analysis==")

    # Prepare hourly traffic per source IP
    df["hour"] = df.startDateTime.dt.floor("h")
    traffic = (
        df.groupby(["source", "hour"])
          .total_bytes
          .sum()
          .unstack(fill_value=0)
    )

    # Sudden spike after inactivity
    flagged = []
    for ip, series in traffic.iterrows():
        mean_, std_ = series.mean(), series.std()
        thresh = mean_ + std_
        inactive = (series == 0).astype(int)
        for i in range(len(series) - 3):
            if (inactive.iloc[i:i+3].sum() == 3
               and series.iloc[i+3] > thresh
               and series.iloc[i+3] > 10000):
                flagged.append((ip, series.index[i+3]))
                break
    print("Sudden‑spike IPs:", flagged or "None")

    # Multiple sources to one destination in an hour
    cnt = df.groupby(["hour", "destination"]).source.nunique()
    mean_s, std_s = cnt.mean(), cnt.std()
    coord = cnt[cnt > mean_s + 2 * std_s]
    print("Coordinated targets:\n", coord if not coord.empty else "None")

    # Destinations with unusually high source diversity
    dst_div = df.groupby("destination").source.nunique()
    m2, s2 = dst_div.mean(), dst_div.std()
    high_div = dst_div[dst_div > m2 + 2 * s2]
    print("High‑diversity dests:\n", high_div if not high_div.empty else "None")

# ----------------------------------------------------------------------
# Identifies suspicious communication patterns:
# - Flags connections whose duration exceeds mean + 2*std seconds.
# - Finds instances where a source uses >2 protocols within a 5‑minute window.
#
# Args:
#     df (pd.DataFrame): Prepared DataFrame from load_and_prepare_data.
# ----------------------------------------------------------------------
def suspicious_communication_patterns(df):
    print("\n==Suspicious Communication Patterns==")

    # Long-duration connections
    df["duration"] = (df.stopDateTime - df.startDateTime).dt.total_seconds()
    mu, sd = df.duration.mean(), df.duration.std()
    dt = mu + 2 * sd
    long = df[df.duration > dt]
    print(f"Long connections (> {dt:.1f}s): {len(long)}")

    # Multi-protocol usage in 5-minute windows
    df["w5"] = df.startDateTime.dt.floor("5min")
    proto = df.groupby(["w5", "source"]).protocolName.nunique()
    multi = proto[proto > 2]
    print("Multi‑protocol instances:", len(multi))

# ----------------------------------------------------------------------
# Entry point: specifies the CSV file path directly in the code,
# runs all analyses, and writes output to 'output.txt'.
# ----------------------------------------------------------------------
if __name__ == "__main__":
    csv_file = "combined.csv"  # <-- Set your CSV filename here
    df = load_and_prepare_data(csv_file)
    with open("output.txt", "w", encoding="utf-8") as out, \
         contextlib.redirect_stdout(out):
        statistical_traffic_analysis(df)
        behavioral_analysis(df)
        suspicious_communication_patterns(df)
