import os
import pandas as pd

# ----------------------------------------------------------------------
# Script: IP Hopping Detection
# 
# This script identifies potential IP-hopping behavior, where a single
# destination IP is contacted by an unusually large number of distinct
# source IPs within fixed time windows.
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# Step 1: Load and preprocess the data
# ----------------------------------------------------------------------
# Read the CSV file containing flow logs into a pandas DataFrame.
df = pd.read_csv("combined.csv")

# Parse the 'startDateTime' column as datetime objects; invalid parses become NaT.
df['startDateTime'] = pd.to_datetime(df['startDateTime'], errors='coerce')

# Keep only the columns needed for detection and drop any rows with missing values.
df = df[['startDateTime', 'source', 'destination']].dropna()

# Sort the DataFrame by timestamp to ensure correct time-series order.
df = df.sort_values('startDateTime')

# Set the timestamp column as the DataFrame index for resampling.
df.set_index('startDateTime', inplace=True)

# ----------------------------------------------------------------------
# Step 2: Define detection parameters
# ----------------------------------------------------------------------
time_window = '24h'  # Resample interval: 24 hours
k = 2                # Threshold multiplier: mean + k * std

# Prepare a list to collect any flagged events.
flagged_results = []

# ----------------------------------------------------------------------
# Step 3: Analyze each destination IP separately
# ----------------------------------------------------------------------
for dest_ip, group in df.groupby('destination'):
    # Count the number of unique source IPs contacting this destination
    # in each 24-hour window.
    unique_counts = group.resample(time_window)['source'].nunique()

    # If there are no data points, skip this IP.
    if unique_counts.empty:
        continue

    # Compute baseline statistics: mean and standard deviation of the counts.
    baseline_mean = unique_counts.mean()
    baseline_std  = unique_counts.std()

    # Define the alert threshold as mean + k * std.
    threshold = baseline_mean + k * baseline_std

    # For each window, check if the unique-source count exceeds the threshold.
    for window_start, count in unique_counts.items():
        if count > threshold:
            # Record any window that exceeds the threshold.
            flagged_results.append({
                'destination': dest_ip,
                'unique_source_ips': count,
                'baseline_mean': baseline_mean,
                'baseline_std': baseline_std,
                'threshold': threshold
            })

# ----------------------------------------------------------------------
# Step 4: Compile flagged events into a DataFrame
# ----------------------------------------------------------------------
flagged_df = pd.DataFrame(flagged_results)

# ----------------------------------------------------------------------
# Step 5: Write detection results to an output file
# ----------------------------------------------------------------------
output_file = "ip_hopping_detection_results.txt"

with open(output_file, "w", newline="\r\n") as f:
    if flagged_df.empty:
        # If no events were flagged, note that in the output.
        f.write("No potential IP hopping events detected.\r\n")
    else:
        # Otherwise, write a header and details for each flagged event.
        f.write("Potential IP Hopping Events (based on mean and threshold):\r\n")
        f.write("----------------------------------------------------------\r\n")
        for _, row in flagged_df.iterrows():
            f.write(f"Destination: {row['destination']}\r\n")
            f.write(f"Unique Source IPs: {row['unique_source_ips']}\r\n")
            f.write(f"Baseline Mean: {row['baseline_mean']:.2f}\r\n")
            f.write(f"Baseline Std: {row['baseline_std']:.2f}\r\n")
            f.write(f"Threshold: {row['threshold']:.2f}\r\n")
            f.write("----------------------------------------------------------\r\n")

# Inform the user that the results have been written.
print(f"Detection results have been written to {output_file}")
