import os
import pandas as pd
import numpy as np

# ----------------------------------------------------------------------
# Generates a consolidated threat attribution and risk analysis report
# from the outputs of different detection modules.
#
# Parameters:
#   stealthy   (pd.DataFrame): Detected stealthy port scan events with
#                              columns ['source_ip', 'unique_ports', 'threshold', 'duration'].
#   ddos       (pd.DataFrame): Detected slow DDoS events with columns
#                              ['destination', 'traffic_volume', 'cusum', 'threshold'].
#   ip_hopping (pd.DataFrame): Detected IP hopping events with columns
#                              ['destination', 'unique_source_ips'].
#   asymmetric (pd.DataFrame): Detected asymmetric flows with columns
#                              ['source', 'destination', 'byte_ratio', 'packet_ratio'].
#
# The function classifies each event as Low-, Medium-, or High-risk based
# on predefined criteria, composes a text report, and writes it to
# 'risk_report.txt'.
# ----------------------------------------------------------------------
def generate_risk_report(stealthy, ddos, ip_hopping, asymmetric):
    report_lines = [
        "Threat Attribution and Risk Analysis Report",
        "============================================="
    ]
    
    # Section: Stealthy Port Scans
    report_lines.append("\nStealthy Port Scans:")
    if not stealthy.empty:
        for _, row in stealthy.iterrows():
            # High risk if very many ports scanned over long duration
            if row['unique_ports'] >= 100 and row.get('duration', 0) >= 7200:
                risk, reasoning = "High-risk", "Very high unique port count and long scan duration."
            # Medium risk if moderate ports scanned over moderate duration
            elif row['unique_ports'] >= 50 and row.get('duration', 0) >= 3600:
                risk, reasoning = "Medium-risk", "Moderate scan activity over an extended period."
            # Otherwise low risk
            else:
                risk, reasoning = "Low-risk", "Limited scan activity."
            report_lines.append(
                f"Source: {row['source_ip']} | Unique Ports: {row['unique_ports']} | Risk: {risk} ({reasoning})"
            )
    else:
        report_lines.append("No stealthy port scans detected.")
    
    # Section: Slow DDoS Attacks
    report_lines.append("\nSlow DDoS Attacks:")
    if not ddos.empty:
        for _, row in ddos.iterrows():
            # High risk if cumulative sum threshold exceeded on low-volume but persistent traffic
            if row['traffic_volume'] < 500 and row['cusum'] > row['threshold']:
                risk, reasoning = "High-risk", "Long duration with many low-volume connections, leading to a high cumulative sum."
            # Medium risk if traffic volume itself is high
            elif row['traffic_volume'] >= 500:
                risk, reasoning = "Medium-risk", "Moderate duration with higher traffic volume."
            # Otherwise low risk
            else:
                risk, reasoning = "Low-risk", "DDoS patterns are not significant."
            report_lines.append(
                f"Destination: {row['destination']} | Risk: {risk} ({reasoning})"
            )
    else:
        report_lines.append("No slow DDoS attacks detected.")
    
    # Section: IP Hopping Behavior
    report_lines.append("\nIP Hopping Behavior:")
    if not ip_hopping.empty:
        for _, row in ip_hopping.iterrows():
            # High risk if many unique sources contact the same destination
            if row['unique_source_ips'] >= 10:
                risk, reasoning = "High-risk", "Large number of unique source IPs contacting the destination."
            # Medium risk if moderate number of unique sources
            elif row['unique_source_ips'] >= 5:
                risk, reasoning = "Medium-risk", "Moderate number of unique source IPs observed."
            # Otherwise low risk
            else:
                risk, reasoning = "Low-risk", "Limited evidence of IP hopping."
            report_lines.append(
                f"Destination: {row['destination']} | Unique Source IPs: {row['unique_source_ips']} | Risk: {risk} ({reasoning})"
            )
    else:
        report_lines.append("No IP hopping behavior detected.")
    
    # Section: Asymmetric Flows
    report_lines.append("\nAsymmetric Flows:")
    if not asymmetric.empty:
        for _, row in asymmetric.iterrows():
            # High risk for extreme byte or packet asymmetry (possible exfil/C2)
            if row['byte_ratio'] > 20 or row['packet_ratio'] > 5:
                risk, reasoning = "High-risk", "Very high asymmetry suggesting potential data exfiltration or command-and-control activity."
            # Medium risk for moderate asymmetry
            elif row['byte_ratio'] > 10 or row['packet_ratio'] > 3:
                risk, reasoning = "Medium-risk", "Moderate asymmetry observed."
            # Otherwise low risk
            else:
                risk, reasoning = "Low-risk", "Asymmetry is within normal limits."
            report_lines.append(
                f"Source: {row['source']} | Destination: {row['destination']} | "
                f"Byte Ratio: {row['byte_ratio']:.2f} | Packet Ratio: {row['packet_ratio']:.2f} | "
                f"Risk: {risk} ({reasoning})"
            )
    else:
        report_lines.append("No asymmetric flows detected.")
    
    # Write the assembled report to disk
    with open('risk_report.txt', 'w') as f:
        f.write("\n".join(report_lines))
    
    print("Risk report has been saved to risk_report.txt.")

# ----------------------------------------------------------------------
# Detects slow, low-and-slow DDoS patterns using a one-sided CUSUM method.
#
# Parameters:
#   df           (pd.DataFrame): Traffic DataFrame indexed by timestamp,
#                                must contain 'destination' and 'totalSourceBytes'.
#   time_window  (str): Pandas resample interval string (e.g., '24h').
#   multiplier   (float): Factor applied to standard deviation for CUSUM threshold.
#
# Returns:
#   pd.DataFrame: Each row contains 'destination', 'traffic_volume',
#                 'cusum', and 'threshold' for flagged windows.
# ----------------------------------------------------------------------
def detect_slow_ddos(df, time_window='24h', multiplier=2):
    alerts = []
    # Group by destination IP to analyze each target separately
    for dst_ip, group in df.groupby('destination'):
        # Sum bytes per interval
        hourly = group['totalSourceBytes'].resample(time_window).sum()
        μ = hourly.mean()
        σ = hourly.std()
        threshold = multiplier * σ
        
        cusum = 0.0
        # Iterate through each time bucket
        for ts, vol in hourly.items():
            dev = vol - μ
            # Only accumulate positive deviations; reset on negative drift
            cusum = cusum + dev if dev > 0 else max(cusum + dev, 0)
            # Flag when CUSUM exceeds threshold
            if cusum > threshold:
                alerts.append({
                    'destination': dst_ip,
                    'traffic_volume': vol,
                    'cusum': cusum,
                    'threshold': threshold
                })
                cusum = 0.0  # reset after alert
    return pd.DataFrame(alerts)

# ----------------------------------------------------------------------
# Main entry point: orchestrates all detection modules and generates
# the final risk report.
# ----------------------------------------------------------------------
def main():
    # Load combined CSV with timestamp parsing
    df = pd.read_csv("combined.csv", low_memory=False, parse_dates=['startDateTime'])
    # Ensure timestamp column is proper datetime and set as index
    df['startDateTime'] = pd.to_datetime(df['startDateTime'], errors='coerce')
    df = df.set_index('startDateTime').sort_index()
    
    # --- Stealthy Port Scan Detection ---
    stealthy_results = []
    time_window = '24h'
    multiplier = 1
    # For each source IP, count distinct destination ports per window
    for src_ip, group in df.groupby('source'):
        port_counts = group.resample(time_window)['destinationPort'].nunique()
        mean_ports = port_counts.mean()
        std_ports = port_counts.std()
        threshold = mean_ports + multiplier * std_ports
        # Flag windows where count exceeds threshold
        for window_start, count in port_counts.items():
            if count > threshold:
                stealthy_results.append({
                    'source_ip': src_ip,
                    'unique_ports': count,
                    'threshold': threshold,
                    'duration': 24 * 3600  # seconds in a day
                })
    stealthy_df = pd.DataFrame(stealthy_results)
    
    # --- Slow DDoS Detection ---
    if 'totalSourceBytes' in df.columns:
        ddos_df = detect_slow_ddos(df)
    else:
        ddos_df = pd.DataFrame()
    
    # --- IP Hopping Detection ---
    ip_hopping_results = []
    k = 2
    for dest_ip, group in df.groupby('destination'):
        unique_counts = group.resample(time_window)['source'].nunique()
        mean_src = unique_counts.mean()
        std_src = unique_counts.std()
        threshold = mean_src + k * std_src
        for window_start, count in unique_counts.items():
            if count > threshold:
                ip_hopping_results.append({
                    'destination': dest_ip,
                    'unique_source_ips': count
                })
    ip_hopping_df = pd.DataFrame(ip_hopping_results)
    
    # --- Asymmetric Flows Detection ---
    required = ['totalSourceBytes', 'totalDestinationBytes', 'totalSourcePackets', 'totalDestinationPackets']
    if all(col in df.columns for col in required):
        df_asym = df.copy()
        # Avoid division by zero by treating zero as NaN
        df_asym['totalSourceBytes'].replace(0, np.nan, inplace=True)
        df_asym['totalSourcePackets'].replace(0, np.nan, inplace=True)
        # Compute byte and packet ratios
        df_asym['byte_ratio'] = df_asym['totalDestinationBytes'] / df_asym['totalSourceBytes']
        df_asym['packet_ratio'] = df_asym['totalDestinationPackets'] / df_asym['totalSourcePackets']
        # Fill NaNs back to zero
        df_asym['byte_ratio'].fillna(0, inplace=True)
        df_asym['packet_ratio'].fillna(0, inplace=True)
        # Flag flows with extreme asymmetry
        asymmetric_df = df_asym[(df_asym['byte_ratio'] > 10) | (df_asym['packet_ratio'] > 10)].copy()
    else:
        asymmetric_df = pd.DataFrame()
    
    # Generate the final risk report
    generate_risk_report(stealthy_df, ddos_df, ip_hopping_df, asymmetric_df)

if __name__ == "__main__":
    main()
