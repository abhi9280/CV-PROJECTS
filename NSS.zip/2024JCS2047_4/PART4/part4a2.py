import os
import pandas as pd

# ----------------------------------------------------------------------
# Configuration parameters
# ----------------------------------------------------------------------
CSV_PATH     = "combined.csv"           # Path to the input CSV file with flow logs
TIME_WINDOW  = '24h'                    # Aggregation interval for traffic volume
MULTIPLIER   = 2                        # Multiplier for standard deviation in CUSUM threshold
OUTPUT_FILE  = "slow_ddos_detection.txt"  # File to which detection results are written

# ----------------------------------------------------------------------
# Step 1: Load and preprocess data
# ----------------------------------------------------------------------
# Read the CSV into a DataFrame; low_memory=False to avoid dtype inference issues
df = pd.read_csv(CSV_PATH, low_memory=False)

# Convert the 'startDateTime' column to datetime objects, invalid parsing → NaT
df['startDateTime']    = pd.to_datetime(df['startDateTime'], errors='coerce')

# Ensure 'totalSourceBytes' is numeric; invalid values become NaN
df['totalSourceBytes'] = pd.to_numeric(df['totalSourceBytes'], errors='coerce')

# Keep only the columns needed for slow‑DDoS detection and drop rows with missing values
df = df[['startDateTime', 'destination', 'totalSourceBytes']].dropna()

# Use the timestamp as the index (required for time‑based resampling) and sort it
df = df.set_index('startDateTime').sort_index()

# ----------------------------------------------------------------------
# Step 2: Detect slow‑DDoS patterns via one‑sided CUSUM
# ----------------------------------------------------------------------
alerts = []  # Will store any detected events

# Process each target IP separately
for dst_ip, group in df.groupby('destination'):
    # Aggregate the sum of source bytes per TIME_WINDOW
    hourly = group['totalSourceBytes'].resample(TIME_WINDOW).sum()

    # Compute baseline mean (μ) and standard deviation (σ)
    μ = hourly.mean()
    σ = hourly.std()

    # Define the CUSUM alert threshold as MULTIPLIER × σ
    threshold = MULTIPLIER * σ

    cusum = 0  # Initialize the cumulative sum

    # Iterate through each time bucket
    for ts, vol in hourly.items():
        dev = vol - μ  # Deviation from the mean

        if dev > 0:
            # Only accumulate positive deviations
            cusum += dev
        else:
            # Decay the CUSUM but never below zero
            cusum = max(cusum + dev, 0)

        # If the CUSUM exceeds the threshold, flag an alert
        if cusum > threshold:
            alerts.append({
                'destination': dst_ip,
                'traffic_volume': vol,
                'cusum': cusum,
                'threshold': threshold
            })
            # Reset CUSUM to avoid repeated alerts for the same event
            cusum = 0

# ----------------------------------------------------------------------
# Step 3: Prepare the output file and write results
# ----------------------------------------------------------------------
# If the output file does not exist, write a header explaining the format
if not os.path.exists(OUTPUT_FILE):
    with open(OUTPUT_FILE, "a", newline="\r\n") as f:
        f.write("=== Slow DDoS Detection Results ===\r\n")
        f.write("Format: destination | traffic_volume | cusum | threshold\r\n")

# Append either the detected alerts or a no‑alert message
with open(OUTPUT_FILE, "a", newline="\r\n") as f:
    if not alerts:
        f.write("No slow‑DDoS events detected.\r\n")
    else:
        for ev in alerts:
            f.write(
                f"{ev['destination']} | "
                f"{ev['traffic_volume']:.0f} | "
                f"{ev['cusum']:.2f} | "
                f"{ev['threshold']:.2f}\r\n"
            )

# Notify the user that results have been written
print(f"Results written to {OUTPUT_FILE}")
