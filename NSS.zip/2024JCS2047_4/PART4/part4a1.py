import os
import pandas as pd

# ----------------------------------------------------------------------
# Reads the specified CSV file and returns a DataFrame with the relevant
# columns ('startDateTime', 'source', 'destinationPort').
#
# - Parses 'startDateTime' to datetime, coercing errors to NaT.
# - Drops rows missing timestamp, source, or destinationPort.
# - Sorts by timestamp and sets it as the index for resampling.
#
# Args:
#     file_path (str): Path to the CSV file.
# Returns:
#     pd.DataFrame: Cleaned and indexed DataFrame.
# ----------------------------------------------------------------------
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, low_memory=False)
    except Exception as e:
        raise RuntimeError(f"Error reading {file_path}: {e}")

    df['startDateTime'] = pd.to_datetime(df['startDateTime'], errors='coerce')
    df = df[['startDateTime', 'source', 'destinationPort']].dropna()
    df = df.sort_values('startDateTime')
    df['destinationPort'] = df['destinationPort'].astype(str)
    df.set_index('startDateTime', inplace=True)
    return df

# ----------------------------------------------------------------------
# Identifies potential stealthy port scan activity per source IP.
#
# For each source IP:
# 1. Resample into fixed time windows (e.g., 24h) and count unique ports.
# 2. Compute threshold = mean + multiplier * std of these counts.
# 3. Flag any window where count exceeds threshold.
#
# Args:
#     df (pd.DataFrame): DataFrame returned by load_data.
#     time_window (str): Resampling interval (pandas offset alias).
#     multiplier (float): Factor applied to standard deviation for threshold.
# Returns:
#     pd.DataFrame: Each row contains 'source_ip', 'unique_ports', 'threshold'.
# ----------------------------------------------------------------------
def detect_stealthy_port_scans(df, time_window='24h', multiplier=1):
    flagged = []
    for src_ip, group in df.groupby('source'):
        # Count distinct destination ports per time window
        port_counts = group.resample(time_window)['destinationPort'].nunique()
        mean_ports = port_counts.mean()
        std_ports  = port_counts.std()
        threshold  = mean_ports + multiplier * std_ports

        # Identify windows exceeding the threshold
        for window_start, count in port_counts[port_counts > threshold].items():
            flagged.append({
                'source_ip': src_ip,
                'unique_ports': count,
                'threshold': threshold
            })

    return pd.DataFrame(flagged)

# ----------------------------------------------------------------------
# Appends stealthy port scan results to a text file.
#
# - If the file doesn't exist, writes a header explaining the format.
# - Writes one line per flagged event, or a no-activity message.
#
# Args:
#     flagged_df (pd.DataFrame): DataFrame from detect_stealthy_port_scans.
#     output_file (str): Path to the output text file.
# ----------------------------------------------------------------------
def save_results(flagged_df, output_file):
    header = (
        "=== Stealthy Port Scan Results ===\r\n"
        "Format: source_ip | unique_ports | threshold_used\r\n"
    )
    # Create file with header if needed
    if not os.path.exists(output_file):
        with open(output_file, "a", newline="\r\n") as f:
            f.write(header)

    # Append flagged results or a no-activity note
    with open(output_file, "a", newline="\r\n") as f:
        if flagged_df.empty:
            f.write("No stealthy port scan activity detected.\r\n")
        else:
            for _, row in flagged_df.iterrows():
                f.write(
                    f"{row['source_ip']} | "
                    f"{row['unique_ports']} | "
                    f"{row['threshold']:.2f}\r\n"
                )

# ----------------------------------------------------------------------
# Main execution flow:
# 1. Load data from the single CSV file.
# 2. Detect stealthy port scan activity.
# 3. Save and report the findings.
# ----------------------------------------------------------------------
def main():
    csv_file = "combined.csv"  # Path to the input CSV
    output_file = "stealthy_port_scan_results.txt"
    df = load_data(csv_file)
    flagged_df = detect_stealthy_port_scans(df)
    save_results(flagged_df, output_file)
    print(f"Results appended to {output_file}")

if __name__ == "__main__":
    main()
