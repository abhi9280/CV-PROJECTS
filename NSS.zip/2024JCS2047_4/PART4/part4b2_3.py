import os
import pandas as pd
import base64
import math
import numpy as np
import re
from collections import Counter

# ----------------------------------------------------------------------
# Extracts Base64-encoded payloads from either source or destination fields,
# decodes them to UTF-8 strings (handling padding issues), and returns a
# DataFrame with an added 'decoded_payload' column.
#
# Args:
#     df (pd.DataFrame): Input DataFrame containing 'sourcePayloadAsBase64'
#                        and/or 'destinationPayloadAsBase64' columns.
# Returns:
#     pd.DataFrame: Copy of input DataFrame with two new columns:
#                   - 'payload': raw Base64 string chosen from source or destination
#                   - 'decoded_payload': UTF-8 decoded string (or raw if decoding fails)
# ----------------------------------------------------------------------
def extract_and_clean_payloads(df):
    # Choose source payload if present, otherwise destination payload
    df['payload'] = df['sourcePayloadAsBase64'].fillna(df['destinationPayloadAsBase64'])
    # Drop rows where neither payload column had data
    df = df.dropna(subset=['payload']).copy()

    def decode_payload(p):
        """
        Decodes a Base64 string to UTF-8, fixing missing padding if necessary.
        If decoding fails, returns the original string.
        """
        # Calculate how many '=' padding characters are needed (Base64 length must be multiple of 4)
        missing_padding = len(p) % 4
        if missing_padding:
            p += '=' * (4 - missing_padding)
        try:
            # Attempt to decode and convert to UTF-8
            return base64.b64decode(p).decode('utf-8', errors='replace')
        except Exception:
            # If decoding fails (non-Base64 data), return raw string
            return p

    # Apply decoding function to each payload
    df['decoded_payload'] = df['payload'].apply(decode_payload)
    return df

# ----------------------------------------------------------------------
# Computes the Shannon entropy of a given string, measuring the
# randomness/unpredictability of its characters.
#
# Args:
#     s (str): Input string.
# Returns:
#     float: Shannon entropy in bits. Returns 0 for empty string.
# ----------------------------------------------------------------------
def calculate_entropy(s):
    if not s:
        return 0.0
    freq = Counter(s)
    total = len(s)
    # Sum over all characters: -p * log2(p)
    return -sum((count / total) * math.log2(count / total) for count in freq.values())

# ----------------------------------------------------------------------
# Adds two new columns to the DataFrame:
# - 'payload_length': number of characters in the decoded payload
# - 'payload_entropy': Shannon entropy of the decoded payload
#
# Args:
#     df (pd.DataFrame): DataFrame with 'decoded_payload' column.
# Returns:
#     pd.DataFrame: Same DataFrame with added numeric feature columns.
# ----------------------------------------------------------------------
def combine_payloads(df):
    # Length of each decoded payload
    df['payload_length'] = df['decoded_payload'].apply(len)
    # Entropy of each decoded payload
    df['payload_entropy'] = df['decoded_payload'].apply(calculate_entropy)
    return df

# ----------------------------------------------------------------------
# Flags payloads as 'abnormal encrypted traffic' if they have high
# entropy (above mean + k*std) but do not contain expected TLS markers.
#
# Args:
#     df (pd.DataFrame): DataFrame with 'payload_entropy' and 'decoded_payload'.
#     k (float): Number of standard deviations above the mean to set threshold.
# Returns:
#     pd.DataFrame: Subset of input rows that meet the flagging criteria.
# ----------------------------------------------------------------------
def flag_encrypted(df, k=2):
    # Compute dynamic entropy threshold
    threshold = df['payload_entropy'].mean() + k * df['payload_entropy'].std()
    print(f"\nUsing entropy threshold: {threshold:.3f} (mean + {k}*std)")

    # Define a quick check for common TLS handshake markers
    def has_tls_markers(payload):
        markers = ["ClientHello", "ServerHello"]
        return any(marker in payload for marker in markers)

    # Flag rows where entropy >= threshold but TLS markers are absent
    mask = (
        (df['payload_entropy'] >= threshold) &
        (~df['decoded_payload'].apply(has_tls_markers))
    )
    return df[mask].copy()

# ----------------------------------------------------------------------
# Scans decoded payloads for known malware Command-and-Control (C2)
# keywords or patterns using regular expressions.
#
# Args:
#     df (pd.DataFrame): DataFrame with 'decoded_payload' column.
#     signature_patterns (list[str], optional): List of regex patterns
#         to identify C2-related terms. Defaults to a common set.
# Returns:
#     pd.DataFrame: Subset of rows where any C2 pattern was found.
# ----------------------------------------------------------------------
def identify_malware_cmds(df, signature_patterns=None):
    if signature_patterns is None:
        signature_patterns = [
            r'\bC2\b', r'\bc2server\b', r'\bcommand\s*and\s*control\b',
            r'\bbeacon\b', r'\bmalware\b', r'\bremote\s+access\b', r'\bcnc\b',
            r'\bbackdoor\b', r'\brat\b', r'\bshell\b', r'\bsocket\b',
            r'\bkeylogger\b', r'\bstealer\b', r'\bexfiltrate\b',
            r'\bdata\s*exfiltration\b', r'\bdns\s+tunnel\b', r'\bheartbeat\b',
            r'\btasking\b', r'\bimplant\b', r'\blisten\b', r'\bdropper\b',
            r'\bcallback\b', r'\bconnect\s+back\b', r'\bsleep\b', r'\bpersist\b'
        ]
    # Compile a single regex pattern for efficiency
    pattern = re.compile('|'.join(signature_patterns), re.IGNORECASE)
    # Flag rows where any pattern matches the decoded payload
    df['c2_flag'] = df['decoded_payload'].apply(lambda x: bool(pattern.search(x)))
    return df[df['c2_flag']].copy()

# ----------------------------------------------------------------------
# Main workflow:
# 1. Load the CSV into a DataFrame.
# 2. Extract, decode, and clean Base64 payloads.
# 3. Compute payload length and entropy features.
# 4. Flag high-entropy payloads missing TLS markers.
# 5. Identify potential malware C2 patterns.
# 6. Write all results to 'results.txt'.
# ----------------------------------------------------------------------
def main():
    # Read the combined CSV file
    file_path = "combined.csv"
    df = pd.read_csv(file_path)

    # Extract and decode payloads
    df_payload = extract_and_clean_payloads(df)

    # Compute length and entropy features
    df_payload = combine_payloads(df_payload)

    # Flag abnormal encrypted traffic
    abnormal_encrypted = flag_encrypted(df_payload, k=2)
    print("\nFlows flagged as abnormal encrypted traffic (high entropy but missing expected markers):")
    print(abnormal_encrypted[['source', 'destination', 'payload_entropy']])

    # Identify C2/malware command patterns
    c2_flows = identify_malware_cmds(df_payload)
    print("\nFlows flagged as potential malware C2 patterns:")
    print(c2_flows[['source', 'destination']])

# ----------------------------------------------------------------------
# Redirect output to 'results.txt' and execute main workflow
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import contextlib
    with open("results.txt", "w", encoding="utf-8") as f, contextlib.redirect_stdout(f):
        main()
