import pandas as pd
import numpy as np
from scipy import stats
from collections import Counter
import math

# ----------------------------------------------------------------------
# Calculates the Shannon entropy of a given text string.
#
# Entropy measures the unpredictability or randomness of the data.
# - Counts the frequency of each character in the text.
# - Converts frequencies to probabilities.
# - Computes entropy as -Σ p * log2(p).
# If the text is empty, returns 0.0.
#
# Args:
#     text (str): Input string whose entropy is to be calculated.
# Returns:
#     float: Shannon entropy value.
# ----------------------------------------------------------------------
def calculate_entropy(text):
    if not text:
        return 0.0
    counts = Counter(text)
    probs = [count / len(text) for count in counts.values()]
    return -sum(p * math.log2(p) for p in probs)

# ----------------------------------------------------------------------
# Analyzes payload fields in a CSV file to detect anomalies based on:
#  - Payload length (number of characters)
#  - Payload entropy (randomness of content)
#  - Outliers defined by Z-score > threshold (default 3)
#
# Workflow:
# 1. Load CSV into DataFrame.
# 2. Ensure payload columns are strings and fill missing with empty.
# 3. Compute features:
#    - src_len, dst_len: length of source/destination payload
#    - src_entropy, dst_entropy: entropy of payload content
# 4. Compute Z-scores for each feature.
# 5. Mark rows as anomalies if any Z-score exceeds threshold.
# 6. Write an anomalies report to the output file.
#
# Args:
#     input_file (str): Path to input CSV containing payload fields.
#     output_file (str): Path to write the anomalies report.
# Returns:
#     int: Number of anomalies detected.
# ----------------------------------------------------------------------
def analyze_payloads(input_file, output_file):
    # Load the CSV, disabling low-memory mode to ensure proper dtypes
    df = pd.read_csv(input_file, low_memory=False)

    # Define the two payload columns and ensure they are strings
    payload_cols = ['sourcePayloadAsUTF', 'destinationPayloadAsUTF']
    df[payload_cols] = df[payload_cols].fillna('').astype(str)

    # Build a new DataFrame of features for each row
    features = pd.DataFrame({
        'src_len': df['sourcePayloadAsUTF'].apply(len),
        'dst_len': df['destinationPayloadAsUTF'].apply(len),
        'src_entropy': df['sourcePayloadAsUTF'].apply(calculate_entropy),
        'dst_entropy': df['destinationPayloadAsUTF'].apply(calculate_entropy),
    })

    # Define the Z-score threshold for flagging anomalies
    zscore_threshold = 3

    # For each feature, compute the absolute Z-score and store it
    for col in ['src_len', 'dst_len', 'src_entropy', 'dst_entropy']:
        features[f'{col}_zscore'] = np.abs(stats.zscore(features[col]))

    # Initialize anomaly flag column
    features['anomaly'] = False

    # Combine conditions: any feature Z-score above threshold marks an anomaly
    anomaly_conditions = (
        (features['src_len_zscore'] > zscore_threshold) |
        (features['dst_len_zscore'] > zscore_threshold) |
        (features['src_entropy_zscore'] > zscore_threshold) |
        (features['dst_entropy_zscore'] > zscore_threshold)
    )
    features.loc[anomaly_conditions, 'anomaly'] = True

    # Merge features back into original DataFrame
    df = pd.concat([df, features], axis=1)

    # Extract only the anomalous rows
    anomalies = df[df['anomaly']]

    # Write a human-readable report listing each anomaly
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("Anomalous Payload Report\n")
        f.write(f"Total anomalies detected: {len(anomalies)}\n\n")
        for _, row in anomalies.iterrows():
            # Show first 200 chars of each payload for context
            f.write(f"Source Payload: {row['sourcePayloadAsUTF'][:200]}...\n")
            f.write(f"Destination Payload: {row['destinationPayloadAsUTF'][:200]}...\n")
            f.write(f"Source Length: {row['src_len']} (Z: {row['src_len_zscore']:.2f})\n")
            f.write(f"Destination Length: {row['dst_len']} (Z: {row['dst_len_zscore']:.2f})\n")
            f.write(f"Source Entropy: {row['src_entropy']:.2f} (Z: {row['src_entropy_zscore']:.2f})\n")
            f.write(f"Destination Entropy: {row['dst_entropy']:.2f} (Z: {row['dst_entropy_zscore']:.2f})\n")
            f.write("-" * 50 + "\n")

    # Return the count of anomalies for potential programmatic use
    return len(anomalies)

# ----------------------------------------------------------------------
# Entry point: invoke the payload analysis on a fixed CSV file
# and write results to a fixed output report.
# ----------------------------------------------------------------------
if __name__ == "__main__":
    input_csv  = "combined.csv"
    output_txt = "anomalies_report.txt"
    num = analyze_payloads(input_csv, output_txt)
    print(f"Anomalies detected: {num}. Report written to {output_txt}")
