import csv
import random
import sys
from pybloom_live import BloomFilter

# Number of fake IPs to generate for false-positive testing
RESULTS_COUNT_FAKE_IPS = 20000

# ----------------------------------------------------------------------
# Reads source and destination IP addresses from a single CSV file.
#
# - Opens the CSV using UTF-8 encoding.
# - Uses DictReader to parse header names.
# - Normalizes header keys to lowercase to handle case variations.
# - Extracts values from 'source' and 'destination' columns if present.
#
# Args:
#     file_path (str): Path to the CSV file.
# Returns:
#     list[str]: All IP addresses found in the file.
# ----------------------------------------------------------------------
def read_ips_from_csv(file_path):
    collected_ips = []
    with open(file_path, 'r', newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        field_map = {col.lower(): col for col in reader.fieldnames or []}
        has_source = 'source' in field_map
        has_dest = 'destination' in field_map

        for row in reader:
            if has_source:
                collected_ips.append(row[field_map['source']])
            if has_dest:
                collected_ips.append(row[field_map['destination']])
    return collected_ips

# ----------------------------------------------------------------------
# Processes a single CSV file to evaluate Bloom filter performance.
#
# Workflow:
# 1. Read all IPs from the CSV.
# 2. Build an exact Python set of unique IPs.
# 3. Generate a pool of fake IPs not in the set for false-positive tests.
# 4. For each target error rate:
#    - Initialize a BloomFilter with capacity = number of unique IPs.
#    - Add every unique IP to the filter.
#    - Measure false negatives (real IPs missed) and false positives.
#    - Compute FN rate, FP rate, accuracy, and memory usage.
# 5. Print a comparison table across error rates.
# 6. Finally, print memory usage of the exact set for baseline comparison.
#
# Args:
#     file_path (str): Path to the CSV file to analyze.
# ----------------------------------------------------------------------
def process_csv_file(file_path):
    # Step 1 & 2: Read IPs and deduplicate
    all_ips = read_ips_from_csv(file_path)
    unique_ips = list(set(all_ips))
    exact_set = set(unique_ips)
    capacity = len(unique_ips)

    # Step 3: Generate fake IPs for false-positive measurement
    test_ips_out = []
    while len(test_ips_out) < RESULTS_COUNT_FAKE_IPS:
        fake_ip = "{}.{}.{}.{}".format(
            random.randint(1, 255),
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255)
        )
        if fake_ip not in exact_set:
            test_ips_out.append(fake_ip)

    # Print table header
    print("\n=== Bloom Filter Comparison Across Error Rates ===")
    print("{:<10} {:>12} {:>12} {:>12} {:>18}".format(
        "ErrorRate", "FP Rate", "FN Rate", "Accuracy", "Memory (KB)"
    ))

    # Step 4: Evaluate for each error rate
    for error_rate in [0.01, 0.02, 0.05, 0.08, 0.10]:
        bloom = BloomFilter(capacity=capacity, error_rate=error_rate)
        for ip in unique_ips:
            bloom.add(ip)

        # False negatives: real IPs that the filter fails to report
        false_negatives = sum(1 for ip in unique_ips if ip not in bloom)
        # False positives: fake IPs that the filter incorrectly reports as present
        false_positives = sum(1 for ip in test_ips_out if ip in bloom)

        fn_rate = false_negatives * 100.0 / len(unique_ips) if unique_ips else 0.0
        fp_rate = false_positives * 100.0 / len(test_ips_out) if test_ips_out else 0.0
        true_negatives = len(test_ips_out) - false_positives
        accuracy = true_negatives * 100.0 / len(test_ips_out) if test_ips_out else 0.0

        bloom_memory_kb = (bloom.num_bits / 8.0) / 1024.0

        print("{:<10} {:>11.2f}% {:>11.2f}% {:>11.2f}% {:>15.2f}".format(
            error_rate, fp_rate, fn_rate, accuracy, bloom_memory_kb
        ))

    # Step 6: Baseline memory usage of exact Python set
    set_overhead = sys.getsizeof(exact_set)
    elements_size = sum(sys.getsizeof(ip) for ip in exact_set)
    total_exact_memory_kb = (set_overhead + elements_size) / 1024.0
    print("\nExact set memory usage: {:.2f} KB ({} unique IPs)".format(
        total_exact_memory_kb, len(exact_set)
    ))

# ----------------------------------------------------------------------
# Entry point: specify the CSV file to analyze below.
# ----------------------------------------------------------------------
if __name__ == "__main__":
    file_path = "combined.csv"
    process_csv_file(file_path)
