import csv
import sys
import random
from collections import defaultdict

# --------------------------------------------
# Count-Min Sketch Data Structure (Custom)
# --------------------------------------------
# This class implements the Count-Min Sketch (CMS) algorithm, which is used for approximate frequency counting.
# It is particularly useful in big data or streaming scenarios where exact counting is too expensive in terms of memory.
# The CMS uses multiple hash functions to index items into a 2D array (depth x width).
# When querying an item's frequency, the minimum count from all hash functions is returned.

class CountMinSketch(object):
    def __init__(self, width=1024, depth=5, seed=42):
        self.width = width  # Number of counters per row (controls accuracy)
        self.depth = depth  # Number of hash functions / rows (controls probability of overestimation)

        # Initialize a list of unique seeds for each hash function
        random.seed(seed)
        self.seeds = [random.randint(1, sys.maxsize) for _ in range(depth)]

        # Initialize the 2D count table
        self.table = [[0] * width for _ in range(depth)]

    def _hash(self, item, seed):
        # Hashes the item with the given seed and maps it to a column index
        return (hash((item, seed)) & 0x7FFFFFFF) % self.width

    def add(self, item):
        # Adds an item to the sketch by incrementing the corresponding counters for all hash functions
        for row in range(self.depth):
            col = self._hash(item, self.seeds[row])
            self.table[row][col] += 1

    def query(self, item):
        # Returns the minimum value across all hash functions (rows) for the item
        # This gives an upper bound estimate of the item's frequency
        return min(
            self.table[row][self._hash(item, self.seeds[row])]
            for row in range(self.depth)
        )

# --------------------------------------------------
# Compute Exact Frequencies for Heavy Hitters (Top IPs)
# --------------------------------------------------
# This function calculates the true frequency of each destination IP using a dictionary.
# Suitable for small datasets where exact counts are feasible.

def exact_heavy_hitters(destination_ips):
    ip_counts = defaultdict(int)
    for ip in destination_ips:
        ip_counts[ip] += 1
    return ip_counts

# --------------------------------------------------
# Compute Approximate Frequencies Using Count-Min Sketch
# --------------------------------------------------
# Populates a Count-Min Sketch structure with all destination IPs
# This helps us approximate frequencies in memory-constrained environments.

def approximate_heavy_hitters(destination_ips, width=2000, depth=5):
    cms = CountMinSketch(width=width, depth=depth)
    for ip in destination_ips:
        cms.add(ip)
    return cms

# -----------------------------------------------
# Read Source and Destination IPs from a CSV File
# -----------------------------------------------
# This function reads IP addresses from a CSV file. It extracts the 'Source' and 'Destination'
# fields from each row. Column names are case-insensitive.

def read_ips_from_csv(file_path):
    source_ips = []
    destination_ips = []
    with open(file_path, 'r', newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        print("Checking file: {}".format(file_path))

        # Normalize header names to handle case differences
        fieldnames = {name.lower(): name for name in reader.fieldnames}

        for row in reader:
            source_ips.append(row[fieldnames['source']])
            destination_ips.append(row[fieldnames['destination']])

    return source_ips, destination_ips

# --------------------------------------------------------
# Main Analysis: Accuracy Comparison of Exact vs Sketch
# --------------------------------------------------------
# Reads IPs from a CSV, shows top heavy hitters using exact counts,
# compares Count-Min Sketch accuracy at different widths,
# and estimates memory usage of both methods.

def process_csv_file(file_path):
    # Read IPs from the given CSV file
    source_ips, destination_ips = read_ips_from_csv(file_path)

    if not destination_ips:
        print("No destination IPs found.")
        return

    # Calculate exact counts of all destination IPs
    exact_counts = exact_heavy_hitters(destination_ips)

    # Estimate memory usage of the exact method using Python's memory model
    exact_ip_set = set(destination_ips)
    set_overhead = sys.getsizeof(exact_ip_set)
    elements_size = sum(sys.getsizeof(ip) for ip in exact_ip_set)
    total_exact_memory_bytes = set_overhead + elements_size
    total_exact_memory_kb = total_exact_memory_bytes / 1024.0

    print("\n[Exact Method]")
    print("Unique IPs (Exact)       :", len(exact_ip_set))
    print("Estimated Memory Usage   : {:.2f} KB".format(total_exact_memory_kb))

    # Identify top 5 most frequent destination IPs
    top_exact = sorted(exact_counts.items(), key=lambda x: x[1], reverse=True)[:5]

    print("\n=== Count-Min Sketch Accuracy vs Width ===")
    print("{:<10} {:>15} {:>18} {:>18}".format("Width", "Avg Error (%)", "Avg Accuracy (%)", "Memory Usage (KB)"))

    # Try different widths to compare accuracy vs memory trade-off
    depth = 5
    widths = [100, 500, 1000, 2000, 5000]

    for width in widths:
        cms = CountMinSketch(width=width, depth=depth)
        for ip in destination_ips:
            cms.add(ip)

        total_error = 0
        total_accuracy = 0

        for ip, true_count in top_exact:
            est_count = cms.query(ip)
            error = abs(est_count - true_count) * 100.0 / true_count
            accuracy = 100.0 - error
            total_error += error
            total_accuracy += accuracy

        avg_error = total_error / len(top_exact)
        avg_accuracy = total_accuracy / len(top_exact)
        memory_kb = (width * depth * 4) / 1024.0  # 4 bytes per cell (integer size)

        print("{:<10} {:>15.2f} {:>18.2f} {:>18.2f}".format(
            width, avg_error, avg_accuracy, memory_kb
        ))

    print("\nExact Top 5 Destination IPs:")
    for ip, count in top_exact:
        print("  {}: {}".format(ip, count))


# Entry point of the script
if __name__ == "__main__":
    # Replace this path with the path to your desired CSV file
    file_path = "combined.csv"
    process_csv_file(file_path)