import csv
import time
import hashlib
import os
import math
from hyperloglog import HyperLogLog
import sys

# -----------------------------------------------
# Returns the exact number of unique IP addresses
# using Python's built-in set to remove duplicates.
# -----------------------------------------------
def exact_count(ip_addresses):
    return len(set(ip_addresses))

# ------------------------------------------------------------------
# Implements the Linear Counting algorithm for cardinality estimation.
#
# Uses a bit array of size `m`. Hashes each IP to a position in the array,
# sets that index to 1, and counts remaining zeros to estimate total cardinality.
# ------------------------------------------------------------------
def linear_counting(ip_addresses, m):
    bit_array = [0] * m
    for ip in ip_addresses:
        h = int(hashlib.sha1(ip.encode()).hexdigest(), 16)
        index = h % m
        bit_array[index] = 1

    V = bit_array.count(0)
    if V == 0:
        return m
    estimate = -m * math.log(V / m)
    return int(estimate)

# ----------------------------------------------------------
# Helper function for Flajolet-Martin algorithm.
# Counts the number of trailing zero bits in binary format.
# ----------------------------------------------------------
def trailing_zero_count(x):
    return len(bin(x)) - len(bin(x).rstrip('0'))

# ---------------------------------------------------------------------
# Implements the Flajolet-Martin algorithm using trailing zero logic.
# Tracks the maximum number of trailing zeroes in hashed values to 
# estimate the cardinality.
# ---------------------------------------------------------------------
def flajolet_martin(ip_addresses):
    max_rho = 0
    for ip in ip_addresses:
        h = int(hashlib.sha1(ip.encode()).hexdigest(), 16)
        rho = trailing_zero_count(h)
        max_rho = max(max_rho, rho)
    phi = 0.77351
    return int((2 ** max_rho) / phi)

# ----------------------------------------------------------------------------
# Uses the HyperLogLog algorithm to estimate cardinality.
#
# Very space-efficient algorithm with tunable error rate.
# ----------------------------------------------------------------------------
def hyperloglog_count(ip_addresses, error_rate=0.01):
    hll = HyperLogLog(error_rate=error_rate)
    for ip in ip_addresses:
        hll.add(ip)
    return len(hll)

# ----------------------------------------------------------------------------------------
# Reads all source and destination IP addresses from a single CSV file.
#
# Skips files with missing or malformed headers, and normalizes header keys.
# ----------------------------------------------------------------------------------------
def read_ips_from_csv(file_path):
    ip_addresses = []
    try:
        with open(file_path, 'r') as file:
            reader = csv.DictReader(file)
            print(f"Checking file: {file_path}")
            if not reader.fieldnames:
                print("No headers found in file. Skipping.")
                return ip_addresses

            fieldnames = {name.lower(): name for name in reader.fieldnames}
            if 'source' not in fieldnames or 'destination' not in fieldnames:
                print(f"Skipping file '{file_path}' - Required columns not found")
                return ip_addresses

            for row in reader:
                ip_addresses.append(row[fieldnames['source']])
                ip_addresses.append(row[fieldnames['destination']])
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    return ip_addresses

# ------------------------------------------------------------------------------------------------
# Evaluates multiple cardinality estimation algorithms using a single CSV file.
#
# Outputs:
#   - Count/Estimate
#   - Memory usage
#   - Execution time
#   - Error rate (when applicable)
# ------------------------------------------------------------------------------------------------
def process_csv_file(file_path, hll_error_rate=0.01, lc_m=65536):
    ip_addresses = read_ips_from_csv(file_path)

    if not ip_addresses:
        print("No valid IP addresses found in the file.")
        return

    print("\n Cardinality Estimation Results \n")

    # Exact Counting
    start = time.time()
    exact_set = set(ip_addresses)
    exact = len(exact_set)
    time_exact = time.time() - start
    set_overhead = sys.getsizeof(exact_set)
    elements_overhead = sum(sys.getsizeof(item) for item in exact_set)
    memory_exact_kb = (set_overhead + elements_overhead) / 1024
    print(f"[Exact Counting]    Count: {exact} | Memory: {memory_exact_kb:.2f} KB | Time: {time_exact:.4f} sec")

    # Linear Counting
    start = time.time()
    linear = linear_counting(ip_addresses, m=lc_m)
    time_linear = time.time() - start
    error_linear = abs(exact - linear) / exact * 100
    memory_linear_kb = lc_m / 8 / 1024
    print(f"[Linear Counting]   Estimate: {linear} | Error: {error_linear:.2f}% | Memory: {memory_linear_kb:.2f} KB | Time: {time_linear:.4f} sec")

    # Flajolet–Martin Counting (with averaging)
    k = 14000
    start = time.time()
    fm_estimates = [0] * k
    for ip in ip_addresses:
        h = int(hashlib.sha1(ip.encode()).hexdigest(), 16)
        bucket = h % k
        rho = trailing_zero_count(h)
        fm_estimates[bucket] = max(fm_estimates[bucket], rho)
    avg_rho = sum(fm_estimates) / k
    phi = 0.77351
    fm = int((2 ** avg_rho) * k / phi)
    time_fm = time.time() - start
    error_fm = abs(exact - fm) / exact * 100
    memory_fm_kb = k * 4 / 1024
    print(f"[Flajolet–Martin]   Estimate: {fm} | Error: {error_fm:.2f}% | Memory: {memory_fm_kb:.2f} KB | Time: {time_fm:.4f} sec")

    # HyperLogLog
    start = time.time()
    hll_obj = HyperLogLog(error_rate=hll_error_rate)
    for ip in ip_addresses:
        hll_obj.add(ip)
    hll = len(hll_obj)
    time_hll = time.time() - start
    error_hll = abs(exact - hll) / exact * 100
    m = int((1.04 / hll_error_rate) ** 2)
    memory_hll_bits = m * 6
    memory_hll_kb = memory_hll_bits / 8 / 1024
    print(f"[HyperLogLog]       Estimate: {hll} | Error: {error_hll:.2f}% | Memory: {memory_hll_kb:.2f} KB | Time: {time_hll:.4f} sec")

# --------------------------------------------------------------------------------------------
# Entry point of the script.
# Modify `file_path` below to specify the CSV file you want to analyze.
# --------------------------------------------------------------------------------------------
if __name__ == "__main__":
    file_path = 'combined.csv'
    process_csv_file(file_path)
