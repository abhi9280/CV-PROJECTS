import pandas as pd
import os
from collections import Counter, defaultdict
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# Create a directory named 'Results' to store all output files such as statistics, CSVs, plots
RESULTS_DIR = 'Results'
os.makedirs(RESULTS_DIR, exist_ok=True)

# ------------------------- Function Definitions -------------------------

# Function to load and preprocess a single CSV file
def parse_csv_file(file_path):
    """
    Reads a CSV file containing network flow data and performs basic preprocessing.

    - Converts the 'generated' timestamp column to datetime format.
    - Computes total 'Packet Size' as the sum of source and destination byte counts.

    Returns:
        DataFrame: The parsed and augmented DataFrame.
    """
    df = pd.read_csv(file_path)
    df['Timestamp'] = pd.to_datetime(df['generated'])  # Convert timestamp to datetime
    df['Packet Size'] = df['totalSourceBytes'] + df['totalDestinationBytes']  # Compute total bytes per flow
    return df

# Function to write key network statistics to a text file
def save_basic_statistics(stats):
    """
    Saves the computed statistics (such as total flows, top IPs, avg packet size, etc.)
    into a human-readable text file for offline review.

    Args:
        stats (dict): Dictionary containing all computed statistics.
    """
    stats_file = os.path.join(RESULTS_DIR, 'statistics.txt')
    with open(stats_file, 'w') as f:
        for key, value in stats.items():
            if isinstance(value, list):  # For list-type stats like top IPs
                f.write(f'{key}:\n')
                for item in value:
                    f.write(f'    {item}\n')
            else:  # For single-value statistics
                f.write(f'{key}: {value}\n')
    print(f'Saved basic statistics to {stats_file}')

# Function to save frequent communicating IP pairs to a CSV
def save_consistent_communication(communication_counts):
    """
    Stores IP address pairs that communicate repeatedly over multiple time windows
    into a CSV file for easy inspection.

    Args:
        communication_counts (dict): Dictionary mapping (src, dst) pairs to their frequency.
    """
    comm_file = os.path.join(RESULTS_DIR, 'consistent_communication.csv')
    pd.DataFrame.from_dict(
        communication_counts, 
        orient='index', 
        columns=['Count']
    ).to_csv(comm_file)
    print(f'Saved consistent communication pairs to {comm_file}')

# Function to save resampled traffic volume data for future use
def save_traffic_volume(traffic_volume):
    """
    Writes the traffic volume (bytes transmitted) over time to a CSV file.

    Args:
        traffic_volume (Series): Time-indexed series of traffic volume.
    """
    traffic_file = os.path.join(RESULTS_DIR, 'traffic_volume.csv')
    traffic_volume.to_csv(traffic_file)
    print(f'Saved traffic volume data to {traffic_file}')

# Function to compute a wide range of network statistics
def compute_basic_statistics(df):
    """
    Analyzes the DataFrame to extract insights from the network traffic logs.

    Returns:
        dict: Dictionary of computed metrics including:
            - Total flows
            - Top protocols
            - Top source/destination IPs
            - Average packet size
            - Variance in per-packet size
            - Most common source-destination pair
    """
    stats = {}

    # Total number of flow records (each row is a flow)
    stats['Total Flows'] = len(df)

    # Count and extract top 5 most used protocols
    protocol_counts = Counter(df['protocolName'])
    stats['Top 5 Protocols'] = protocol_counts.most_common(5)

    # Identify top 10 IPs involved in sending data
    src_ip_counts = Counter(df['source'])
    stats['Top 10 Source IPs'] = src_ip_counts.most_common(10)

    # Identify top 10 IPs involved in receiving data
    dst_ip_counts = Counter(df['destination'])
    stats['Top 10 Destination IPs'] = dst_ip_counts.most_common(10)

    # Compute global average packet size over all flows
    total_bytes = df['totalSourceBytes'].sum() + df['totalDestinationBytes'].sum()
    total_packets = df['totalSourcePackets'].sum() + df['totalDestinationPackets'].sum()
    stats['Average Packet Size'] = total_bytes / total_packets if total_packets != 0 else 0

    # Calculate per-flow packet size and its variance
    df['TotalBytes'] = df['totalSourceBytes'] + df['totalDestinationBytes']
    df['TotalPackets'] = df['totalSourcePackets'] + df['totalDestinationPackets']
    df = df[df['TotalPackets'] > 0]  # Prevent division by zero
    df['PerPacketSize'] = df['TotalBytes'] / df['TotalPackets']
    stats['Packet Size Variance'] = np.var(df['PerPacketSize'])

    # Find the most frequently observed source-destination pair
    src_dst_pairs = list(zip(df['source'], df['destination']))
    stats['Most Common Src-Dst Pair'] = Counter(src_dst_pairs).most_common(1)[0]

    return stats

# Function to detect IP pairs that communicate consistently across time windows
def identify_communicating_ips(df, time_window='5min'):
    """
    Groups traffic into fixed-size time windows (e.g., 5 minutes) and tracks IP pairs
    that consistently appear in multiple windows.

    Returns:
        dict: {(source, destination): count} where count > 1
    """
    communication_counts = defaultdict(int)
    df_resampled = df.set_index('Timestamp').resample(time_window)

    for _, group in df_resampled:
        src_dst_pairs = list(zip(group['source'], group['destination']))
        for pair in src_dst_pairs:
            communication_counts[pair] += 1

    # Return only pairs that occurred more than once (i.e., consistently)
    return {k: v for k, v in communication_counts.items() if v > 1}

# ------------------------- Main Program -------------------------

def main(file_path):
    """
    Entry point of the program. Performs the full workflow:
    - Load and process CSV
    - Compute basic statistics
    - Detect frequent communication pairs
    - Save all results
    """
    df = parse_csv_file(file_path)
    stats = compute_basic_statistics(df)
    save_basic_statistics(stats)
    consistent_communication = identify_communicating_ips(df)
    save_consistent_communication(consistent_communication)

# Define path to input CSV file and invoke main function
if __name__ == "__main__":
    file_path = 'combined.csv'  # Change this to your actual file path if needed
    main(file_path)
