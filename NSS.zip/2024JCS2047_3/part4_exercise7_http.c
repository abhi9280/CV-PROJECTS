#include "http.h"
#include <sys/param.h>
#ifndef BSD
#include <sys/sendfile.h>
#endif
#include <sys/uio.h>
#include <sys/stat.h>
#include <ctype.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define ENV_MAX 8192

void fdprintf(int fd, const char *fmt, ...)
{
    char *s = NULL;
    va_list ap;
    va_start(ap, fmt);
    if (vasprintf(&s, fmt, ap) < 0) {
        va_end(ap);
        return;
    }
    va_end(ap);
    if (s) {
        write(fd, s, strlen(s));
        free(s);
    }
}

void touch(const char *name)
{
    if (access("/tmp/grading", F_OK) < 0)
        return;
    char pn[1024];
    snprintf(pn, sizeof(pn), "/tmp/%s", name);
    int fd = open(pn, O_RDWR | O_CREAT | O_NOFOLLOW, 0666);
    if (fd >= 0)
        close(fd);
}

static int safe_append(char **dst, size_t *remaining, const char *fmt, ...)
{
    if (*remaining <= 1)
        return -1;
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(*dst, *remaining, fmt, ap);
    va_end(ap);
    if (n < 0 || (size_t)n >= *remaining) {
        *remaining = 0;
        return -1;
    }
    *dst += n;
    *remaining -= n;
    if (*remaining > 0) {
        **dst = '\0';
        (*dst)++;
        (*remaining)--;
    }
    return 0;
}

static int append_env_var(char **envp, size_t *remaining, const char *name, const char *value)
{
    return safe_append(envp, remaining, "%s=%s", name, value);
}

void url_decode(char *dst, const char *src)
{
    for (;;) {
        if (src[0] == '%' && src[1] && src[2]) {
            char hexbuf[3] = { src[1], src[2], '\0' };
            *dst = (char)strtol(hexbuf, NULL, 16);
            src += 3;
        } else if (src[0] == '+') {
            *dst = ' ';
            src++;
        } else {
            *dst = *src;
            src++;
            if (*dst == '\0')
                break;
        }
        dst++;
    }
}

static void remove_dotdot(char *pn)
{
    char *p;
    while ((p = strstr(pn, "..")) != NULL) {
        p[0] = '_';
        p[1] = '_';
    }
}

void split_path(char *pn)
{
    remove_dotdot(pn);
    struct stat st;
    char *slash = NULL;
    while (1) {
        if (stat(pn, &st) < 0) {
            if (errno != ENOTDIR && errno != ENOENT)
                break;
        } else {
            if (S_ISREG(st.st_mode))
                break;
        }
        if (slash)
            *slash = '/';
        else
            slash = pn + strlen(pn);
        while (--slash > pn) {
            if (*slash == '/') {
                *slash = '\0';
                break;
            }
        }
        if (slash == pn) {
            slash = NULL;
            break;
        }
    }
    if (slash) {
        *slash = '/';
        setenv("PATH_INFO", slash, 1);
        *slash = '\0';
    }
    const char *docroot = getenv("DOCUMENT_ROOT");
    if (!docroot)
        docroot = "";
    setenv("SCRIPT_NAME", pn + strlen(docroot), 1);
    setenv("SCRIPT_FILENAME", pn, 1);
}

int http_read_line(int fd, char *buf, size_t size)
{
    size_t i = 0;
    char ch;
    while (i < size - 1) {
        int cc = read(fd, &ch, 1);
        if (cc <= 0)
            break;
        if (ch == '\r')
            continue;
        if (ch == '\n') {
            buf[i] = '\0';
            return 0;
        }
        buf[i++] = ch;
    }
    if (i >= size - 1) {
        buf[size - 1] = '\0';
        return -1;
    }
    return (i > 0) ? 0 : -1;
}

static const char *process_request_line(char *buf, char *reqpath, char *env, size_t *env_len)
{
    char *sp1, *sp2, *qp;
    char *envp = env;
    size_t remaining = ENV_MAX;
    sp1 = strchr(buf, ' ');
    if (!sp1)
        return "Cannot parse HTTP request (1)";
    *sp1++ = '\0';
    if (*sp1 != '/')
        return "Bad request path";
    qp = strchr(sp1, '?');
    if (qp) {
        *qp = '\0';
        if (safe_append(&envp, &remaining, "QUERY_STRING=%s", qp + 1) < 0)
            return "Environment buffer overflow";
    }
    sp2 = strchr(sp1, ' ');
    if (!sp2)
        return "Malformed HTTP request: Missing protocol version";
    *sp2++ = '\0';
    if (strcmp(buf, "GET") && strcmp(buf, "POST"))
        return "Unsupported request (not GET or POST)";
    if (safe_append(&envp, &remaining, "REQUEST_METHOD=%s", buf) < 0)
        return "Environment buffer overflow";
    if (safe_append(&envp, &remaining, "SERVER_PROTOCOL=%s", sp2) < 0)
        return "Environment buffer overflow";
    url_decode(reqpath, sp1);
    if (safe_append(&envp, &remaining, "REQUEST_URI=%s", reqpath) < 0)
        return "Environment buffer overflow";
    if (safe_append(&envp, &remaining, "SERVER_NAME=zoobar.org") < 0)
        return "Environment buffer overflow";
    *env_len = (size_t)(envp - env + 1);
    return NULL;
}

static const char *process_header_line(char *buf, char *decoded_value, size_t value_size,
                                         char *env_key, size_t key_size)
{
    char *sp = strchr(buf, ' ');
    if (!sp)
        return "Header parse error (1)";
    *sp++ = '\0';
    if (strlen(buf) == 0)
        return "Header parse error (2)";
    char *colon = &buf[strlen(buf) - 1];
    if (*colon != ':')
        return "Header parse error (3)";
    *colon = '\0';
    for (size_t i = 0; i < strlen(buf); i++) {
        buf[i] = toupper((unsigned char)buf[i]);
        if (buf[i] == '-')
            buf[i] = '_';
    }
    strncpy(env_key, buf, key_size - 1);
    env_key[key_size - 1] = '\0';
    url_decode(decoded_value, sp);
    return NULL;
}

const char *http_request_line(int fd, char *reqpath, char *env, size_t *env_len)
{
    static char buf[8192];
    touch("http_request_line");
    if (http_read_line(fd, buf, sizeof(buf)) < 0)
        return "Socket IO error";
    if (strlen(buf) >= sizeof(buf) - 1)
        return "HTTP request line too long";
    return process_request_line(buf, reqpath, env, env_len);
}

const char *http_request_headers(int fd)
{
    static char buf[8192];
    char value[512];
    char key[512];
    char envvar[512];
    touch("http_request_headers");
    while (1) {
        if (http_read_line(fd, buf, sizeof(buf)) < 0)
            return "Socket IO error";
        if (buf[0] == '\0')
            break;
        const char *err = process_header_line(buf, value, sizeof(value), key, sizeof(key));
        if (err)
            return err;
        if (strcmp(key, "CONTENT_TYPE") != 0 && strcmp(key, "CONTENT_LENGTH") != 0) {
            snprintf(envvar, sizeof(envvar), "HTTP_%s", key);
            setenv(envvar, value, 1);
        } else {
            setenv(key, value, 1);
        }
    }
    return 0;
}

void env_deserialize(const char *env, size_t len)
{
    while (1) {
        char *p = strchr((char *)env, '=');
        if (!p || (size_t)(p - env) > len)
            break;
        *p++ = '\0';
        setenv(env, p, 1);
        p += strlen(p) + 1;
        len -= (size_t)(p - env);
        env = p;
    }
    setenv("GATEWAY_INTERFACE", "CGI/1.1", 1);
    setenv("REDIRECT_STATUS", "200", 1);
}

void http_err(int fd, int code, const char *fmt, ...)
{
    fdprintf(fd, "HTTP/1.0 %d Error\r\n", code);
    fdprintf(fd, "Content-Type: text/html\r\n");
    fdprintf(fd, "\r\n");
    fdprintf(fd, "<H1>An error occurred</H1>\r\n");
    char *msg = NULL;
    va_list ap;
    va_start(ap, fmt);
    if (vasprintf(&msg, fmt, ap) < 0)
        msg = NULL;
    va_end(ap);
    if (msg) {
        fdprintf(fd, "%s\n", msg);
        warnx("[%d] Request failed: %s", getpid(), msg);
        free(msg);
    } else {
        warnx("[%d] Request failed: (error message formatting failed)", getpid());
    }
    close(fd);
}

void dir_join(char *dst, const char *dirname, const char *filename)
{
    strncpy(dst, dirname, 1024);
    dst[1023] = '\0';
    if (dst[strlen(dst) - 1] != '/')
        strncat(dst, "/", 1024 - strlen(dst) - 1);
    strncat(dst, filename, 1024 - strlen(dst) - 1);
}

static int find_index_file(const char *directory, char *index_path, size_t size)
{
    static const char *const indices[] = {"index.html", "index.php", "index.cgi", NULL};
    char temp[1024];
    struct stat st;
    for (int i = 0; indices[i]; i++) {
        dir_join(temp, directory, indices[i]);
        if (stat(temp, &st) == 0 && S_ISREG(st.st_mode)) {
            strncpy(index_path, temp, size - 1);
            index_path[size - 1] = '\0';
            return 0;
        }
    }
    return -1;
}

void http_serve_none(int fd, const char *pn)
{
    http_err(fd, 404, "File does not exist: %s", pn);
}

void http_serve_file(int fd, const char *pn)
{
    if (getenv("PATH_INFO")) {
        char buf[1024];
        snprintf(buf, sizeof(buf), "%s%s", pn, getenv("PATH_INFO"));
        http_serve_none(fd, buf);
        return;
    }
    int filefd = open(pn, O_RDONLY);
    if (filefd < 0) {
        http_err(fd, 500, "open %s: %s", pn, strerror(errno));
        return;
    }
    const char *ext = strrchr(pn, '.');
    const char *mimetype = "text/html";
    if (ext && strcmp(ext, ".css") == 0) {
        mimetype = "text/css";
    } else if (ext && strcmp(ext, ".jpg") == 0) {
        mimetype = "image/jpeg";
    }
    fdprintf(fd, "HTTP/1.0 200 OK\r\n");
    fdprintf(fd, "Content-Type: %s\r\n", mimetype);
    fdprintf(fd, "\r\n");
#ifndef BSD
    struct stat st;
    if (!fstat(filefd, &st)) {
        off_t len = st.st_size;
        if (sendfile(fd, filefd, 0, len) < 0) {
            err(1, "sendfile");
        }
    }
#else
    off_t len = 0;
    if (sendfile(filefd, fd, 0, &len, 0, 0) < 0) {
        err(1, "sendfile");
    }
#endif
    close(filefd);
}

void http_serve_directory(int fd, const char *pn)
{
    char index_path[1024];
    if (find_index_file(pn, index_path, sizeof(index_path)) != 0) {
        http_err(fd, 403, "No index file in %s", pn);
        return;
    }
    http_serve(fd, index_path);
}

void http_serve_executable(int fd, const char *pn)
{
    char buf[1024], headers[4096];
    int pipefd[2], statusprinted = 0, ret;
    if (pipe(pipefd) < 0) {
        http_err(fd, 500, "pipe: %s", strerror(errno));
        return;
    }
    pid_t child = fork();
    if (child < 0) {
        http_err(fd, 500, "fork: %s", strerror(errno));
        return;
    }
    if (child == 0) {
        signal(SIGPIPE, SIG_DFL);
        signal(SIGCHLD, SIG_DFL);
        dup2(fd, 0);
        close(fd);
        dup2(pipefd[1], 1);
        close(pipefd[0]);
        close(pipefd[1]);
        execl(pn, pn, NULL);
        http_err(1, 500, "execl %s: %s", pn, strerror(errno));
        _exit(1);
    } else {
        close(pipefd[1]);
        while (1) {
            if (http_read_line(pipefd[0], buf, sizeof(buf)) < 0) {
                http_err(fd, 500, "Premature end of script headers");
                close(pipefd[0]);
                return;
            }
            if (!*buf)
                break;
            if (!statusprinted && strncasecmp("Status: ", buf, 8) == 0) {
                fdprintf(fd, "HTTP/1.0 %s\r\n", buf + 8);
                statusprinted = 1;
            } else if (statusprinted) {
                fdprintf(fd, "%s\r\n", buf);
            } else {
                ret = snprintf(headers, sizeof(headers), "%s\r\n", buf);
                if (ret < 0 || ret >= (int)sizeof(headers)) {
                    http_err(fd, 500, "Too many script headers");
                    close(pipefd[0]);
                    return;
                }
            }
        }
        if (statusprinted)
            fdprintf(fd, "\r\n");
        else
            fdprintf(fd, "HTTP/1.0 200 OK\r\n%s\r\n", headers);
        while ((ret = read(pipefd[0], buf, sizeof(buf))) > 0) {
            write(fd, buf, ret);
        }
        close(fd);
        close(pipefd[0]);
        while (waitpid(-1, NULL, WNOHANG) > 0) { }
    }
}

void http_serve(int fd, const char *name)
{
    void (*handler)(int, const char *) = http_serve_none;
    char pn[1024];
    struct stat st;
    if (!getcwd(pn, sizeof(pn))) {
        http_err(fd, 500, "getcwd failed: %s", strerror(errno));
        return;
    }
    setenv("DOCUMENT_ROOT", pn, 1);
    if (strlen(name) + strlen(pn) + 1 >= sizeof(pn)) {
        http_err(fd, 500, "Request too long");
        return;
    }
    strncat(pn, name, sizeof(pn) - strlen(pn) - 1);
    split_path(pn);
    if (!stat(pn, &st)) {
        if (S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR))
            handler = http_serve_executable;
        else if (S_ISDIR(st.st_mode))
            handler = http_serve_directory;
        else
            handler = http_serve_file;
    }
    handler(fd, pn);
}

ssize_t sendfd(int socket, const void *buffer, size_t length, int fd)
{
    struct iovec iov = {(void *)buffer, length};
    char buf[CMSG_LEN(sizeof(int))];
    struct cmsghdr *cmsg = (struct cmsghdr *)buf;
    cmsg->cmsg_len = sizeof(buf);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    *((int *)CMSG_DATA(cmsg)) = fd;
    struct msghdr msg = {0};
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsg;
    msg.msg_controllen = cmsg->cmsg_len;
    ssize_t r = sendmsg(socket, &msg, 0);
    if (r < 0)
        warn("sendmsg");
    return r;
}

ssize_t recvfd(int socket, void *buffer, size_t length, int *fd)
{
    struct iovec iov = {buffer, length};
    char buf[CMSG_LEN(sizeof(int))];
    struct cmsghdr *cmsg = (struct cmsghdr *)buf;
    cmsg->cmsg_len = sizeof(buf);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    struct msghdr msg = {0};
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsg;
    msg.msg_controllen = cmsg->cmsg_len;
    ssize_t r = recvmsg(socket, &msg, 0);
    if (r < 0 && errno == EINTR)
        r = recvmsg(socket, &msg, 0);
    if (r < 0)
        warn("recvmsg");
    else
        *fd = *((int *)CMSG_DATA(cmsg));
    return r;
}
