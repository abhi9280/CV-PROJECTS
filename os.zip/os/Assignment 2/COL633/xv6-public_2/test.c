#include "types.h"
#include "stat.h"
#include "user.h"


int main () {
    int i=1;
    while(1)
    {
        printf(1," : %d\n",i);
        i++;
        sleep(100);
    }

    return 0;
}