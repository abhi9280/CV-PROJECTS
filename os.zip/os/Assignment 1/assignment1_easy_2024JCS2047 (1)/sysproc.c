#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0; 
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_gethistory(void)
{
  int i, j;
  struct history_entry temp; 
  
  for(i = 0; i < history_count - 1; i++){
    for(j = 0; j < history_count - i - 1; j++){
      if(history_list[j].pid > history_list[j+1].pid){
        temp = history_list[j];
        history_list[j] = history_list[j+1];
        history_list[j+1] = temp;
      }
    }
  }

  for(i = 0; i < history_count; i++){
    cprintf("%d %s %d\n", history_list[i].pid,
            history_list[i].name, history_list[i].mem);
  }
  return 0;
}

int
sys_chmod(void)
{
  char *path;
  int mode;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &mode) < 0)
    return -1;
  if(mode < 0 || mode > 7)
    return -1;

  begin_op();
  if((ip = namei(path)) == 0){
    end_op();
    return -1;
  }
  ilock(ip);
  ip->permission_bit = mode;  
  iupdate(ip);
  iunlockput(ip);
  end_op();
  return 0;
}

int sys_block(void) {
  struct proc *curproc = myproc();
	int syscall_id;
	
	if(argint(0, &syscall_id) < 0){
		return -1;
	}
  if (syscall_id == 1 || syscall_id == 2)
    return -1;

  if (syscall_id < 0 || syscall_id >= 64)
    return -1;

  curproc->blocked_calls[syscall_id] = 1;
  return 0;
}

int sys_unblock(void) {
  struct proc *curproc = myproc();
  int syscall_id;
	
	if(argint(0, &syscall_id) < 0){
		return -1;
	}

  if (syscall_id < 0 || syscall_id >= 64)
    return -1;

  curproc->blocked_calls[syscall_id] = 0;
  return 0;
}