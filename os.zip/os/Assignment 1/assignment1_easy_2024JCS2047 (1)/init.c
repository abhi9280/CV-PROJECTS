#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

void trim(char *s) {
  int i = 0;
  while (s[i] != '\0')
    i++;
  while (i > 0 && (s[i-1] == '\n')) {
    s[i-1] = '\0';
    i--;
  }
}

int my_strcmp(const char *s, const char *t)
{
  while (*s && *s == *t) {
    s++;
    t++;
  }
  return (unsigned char)*s - (unsigned char)*t;
}

char *argv[] = { "sh", 0 };

int main(void)
{
  int pid, wpid;

  if (open("console", O_RDWR) < 0) {
    mknod("console", 1, 1);
    open("console", O_RDWR);
  }
  dup(0);  
  dup(0);  

  {
    int attempts = 3;
    char user[32], pass[32];

    while (attempts > 0) {
      printf(1, "Enter username: ");
      gets(user, sizeof(user));
      trim(user);

      if (my_strcmp(user, USERNAME) != 0) {
        printf(1, "Invalid username\n");
        attempts--;
        continue;
      }

      printf(1, "Enter password: ");
      gets(pass, sizeof(pass));
      trim(pass);

      if (my_strcmp(pass, PASSWORD) == 0) {
        printf(1, "Login successful\n");
        goto login_success;
      } else {
        printf(1, "Invalid password\n");
        attempts--;
      }
    }
    
    printf(1, "Login disabled\n");
    for (;;);  
  }

login_success:

  for(;;){
    printf(1, "init: starting sh\n");
    pid = fork();
    if(pid < 0){
      printf(1, "init: fork failed\n");
      exit();
    }
    if(pid == 0){
      exec("sh", argv);
      printf(1, "init: exec sh failed\n");
      exit();
    }
    while((wpid = wait()) >= 0 && wpid != pid)
      printf(1, "zombie!\n");
  }
}
